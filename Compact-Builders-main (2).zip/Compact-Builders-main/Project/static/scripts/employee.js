var deleteEmployeeModal = document.getElementById('deleteEmployeeModal');
deleteEmployeeModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var employeeId = button.getAttribute('data-id');
    var employeeName = button.getAttribute('data-name');

    // Update modal content
    var employeeNameElement = deleteEmployeeModal.querySelector('#employeeName');
    var employeeIdElement = deleteEmployeeModal.querySelector('#employeeId');
    var confirmDeleteButton = deleteEmployeeModal.querySelector('#confirmDeleteButton');

    employeeNameElement.textContent = employeeName;
    employeeIdElement.textContent = employeeId;

    // Update the href attribute with the correct delete URL
    confirmDeleteButton.setAttribute('href', '/delete-employee/' + employeeId);
});

function viewEmployee(id, name, dob, gender, contact, email, address, position, manager, doj, imagePath) {
    // Set the values in the modal
    document.getElementById("employeeModalId").innerText = id;
    document.getElementById("employeeModalName").innerText = name;
    document.getElementById("employeeModalDob").innerText = dob;
    document.getElementById("employeeModalGender").innerText = gender;
    document.getElementById("employeeModalContact").innerText = contact;
    document.getElementById("employeeModalEmail").innerText = email;
    document.getElementById("employeeModalAddress").innerText = address;
    document.getElementById("employeeModalPosition").innerText = position;
    document.getElementById("employeeModalManager").innerText = manager;
    document.getElementById("employeeModalDoj").innerText = doj;

    // Set the employee image in the modal (if available)
    const employeeModalImage = document.getElementById("employeeModalImage");
    if (imagePath) {
        employeeModalImage.src = imagePath;
    } else {
        employeeModalImage.src = "{{ url_for('static', filename='uploads/photo/default.png') }}";
    }
}

document.getElementById('searchInput').addEventListener('keyup', function () {
    var searchValue = this.value.trim().toLowerCase();
    var table = document.getElementById('employeeTable');
    var rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

    // If search value is empty, show all rows and clear any previous highlights
    if (!searchValue) {
        for (var i = 0; i < rows.length; i++) {
            var cells = rows[i].getElementsByTagName('td');
            cells[0].innerHTML = cells[0].textContent; // Reset Employee ID cell
            cells[2].innerHTML = cells[2].textContent; // Reset Name cell
            rows[i].style.display = '';
        }
        return;
    }

    for (var i = 0; i < rows.length; i++) {
        var cells = rows[i].getElementsByTagName('td');
        var employeeIdCell = cells[0];
        var nameCell = cells[2];

        var employeeIdText = employeeIdCell.textContent;
        var nameText = nameCell.textContent;

        var employeeIdHighlighted = employeeIdText.replace(new RegExp('(' + searchValue + ')', 'gi'), function (matched) {
            return '<mark>' + matched + '</mark>';
        });

        var nameHighlighted = nameText.replace(new RegExp('(' + searchValue + ')', 'gi'), function (matched) {
            return '<mark>' + matched + '</mark>';
        });

        if (employeeIdText.toLowerCase().includes(searchValue) || nameText.toLowerCase().includes(searchValue)) {
            rows[i].style.display = '';
            // Update cell content with highlighted text
            employeeIdCell.innerHTML = employeeIdHighlighted;
            nameCell.innerHTML = nameHighlighted;
        } else {
            rows[i].style.display = 'none';
        }
    }
});

function previewImage(event, previewId) {
    const file = event.target.files[0];
    const preview = document.getElementById(previewId);

    // If no file is selected (input cleared), hide the preview
    if (!file) {
        preview.src = '';
        preview.style.display = 'none';
        return;
    }

    // Check file size (max 1MB)
    if (file.size > (5 * 1048576)) {  // 1MB = 1048576 bytes
        alert('File size exceeds 5MB. Please upload a smaller file.');
        event.target.value = '';  // Reset the input
        preview.src = '';  // Clear the preview source
        preview.style.display = 'none';  // Hide the preview
        return;
    }

    // Ensure the file is an image (for image previews only)
    if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function () {
            preview.src = reader.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        alert('File size exceeds 5MB. Please upload a smaller image.');
        preview.src = '';  // Clear the preview source for non-image files
        preview.style.display = 'none';  // Hide preview for non-image files
    }
}

window.setTimeout(function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        alert.classList.remove('show');
        alert.classList.add('fade');
        alert.style.display = 'none';
    });
}, 5000);

document.addEventListener('DOMContentLoaded', function () {
    var editModal = document.getElementById('editEmployeeModal');

    editModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Button that triggered the modal
        var modal = editModal.querySelector('.modal-body');

        // Get data attributes from the clicked button
        var employeeId = button.getAttribute('data-id');
        var name = button.getAttribute('data-name');
        var gender = button.getAttribute('data-gender');
        var dob = button.getAttribute('data-dob');
        var aadhaar = button.getAttribute('data-aadhaar');
        var pan = button.getAttribute('data-pan');
        var contact = button.getAttribute('data-contact');
        var email = button.getAttribute('data-email');
        var address = button.getAttribute('data-address');
        var position = button.getAttribute('data-position');
        var manager = button.getAttribute('data-manager');
        var doj = button.getAttribute('data-doj');
        var upi = button.getAttribute('data-upi');
        var bankAccount = button.getAttribute('data-bankaccount');

        // Populate the form fields using the 'value' attribute
        document.getElementById('editEmployeeId').value = employeeId;
        document.getElementById('editName').value = name;
        document.getElementById('editGender').value = gender;
        document.getElementById('editDob').value = dob;
        document.getElementById('editAadhaar').value = aadhaar;
        document.getElementById('editpan').value = pan;
        document.getElementById('editContact').value = contact;
        document.getElementById('editEmail').value = email;
        document.getElementById('editAddress').value = address;
        document.getElementById('editPosition').value = position;
        document.getElementById('editManager').value = manager;
        document.getElementById('editDoj').value = doj;
        document.getElementById('editUpi').value = upi;
        document.getElementById('editBankAccount').value = bankAccount;
    });
});
