# mysql_database/db_config.py

MYSQL_HOST = 'host' # for eg. localhost
MYSQL_USER = 'user' # for eg. root
MYSQL_PASSWORD = 'password' # your password
MYSQL_DB = 'database' # name of database