from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, make_response, Response
from static.mysql_database.db_config import MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from sqlalchemy.exc import IntegrityError
from flask_sqlalchemy import SQLAlchemy
from deepface import DeepFace
from datetime import datetime
from sqlalchemy import case
import pandas as pd
import cv2
import os


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages
login_manager = LoginManager(app)
login_manager.login_view = 'login'

app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER_img'] = 'static/uploads/photo'
app.config['UPLOAD_FOLDER_aadhaar'] = 'static/uploads/aadhaar'
app.config['UPLOAD_FOLDER_pan'] = 'static/uploads/pan'

if not os.path.exists(app.config['UPLOAD_FOLDER_img']):
    os.makedirs(app.config['UPLOAD_FOLDER_img'])
if not os.path.exists(app.config['UPLOAD_FOLDER_aadhaar']):
    os.makedirs(app.config['UPLOAD_FOLDER_aadhaar'])
if not os.path.exists(app.config['UPLOAD_FOLDER_pan']):
    os.makedirs(app.config['UPLOAD_FOLDER_pan'])

db = SQLAlchemy(app)

class Employee(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    aadhaar = db.Column(db.String(20), nullable=False, unique=True)
    pan = db.Column(db.String(20), nullable=False, unique=True)
    contact = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    address = db.Column(db.Text, nullable=False)
    position = db.Column(db.String(100), nullable=False)
    manager = db.Column(db.String(100), nullable=True)
    doj = db.Column(db.Date, nullable=False)
    upi = db.Column(db.String(50), nullable=False)
    bank_account = db.Column(db.String(50), nullable=False)
    image_path = db.Column(db.String(255), nullable=True)
    aadhaar_path = db.Column(db.String(255), nullable=True)
    pan_path = db.Column(db.String(255), nullable=True)
    data_added_by = db.Column(db.String(150), nullable=True)

    # Relationships
    logins = db.relationship('Login', backref='employee_login', lazy=True, passive_deletes=True, cascade='all, delete-orphan')
    payroll_records = db.relationship('Payroll', backref='employee_payroll', lazy=True, cascade='all, delete-orphan')

class Login(db.Model, UserMixin):    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id', ondelete='CASCADE'), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False)
    data_added_by = db.Column(db.String(150), nullable=True)
    # Relationship to Employee
    employee = db.relationship('Employee', backref=db.backref('login_info', uselist=False))
    
class Payroll(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id', ondelete='CASCADE'), nullable=False)
    payment_mode = db.Column(db.String(50), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    salary_month = db.Column(db.String(20), nullable=False)
    salary_year = db.Column(db.String(4), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    # Define the relationship with Employee
    employee = db.relationship('Employee', backref='payroll_info', lazy=True)

class Leave(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id', ondelete='CASCADE'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    leave_type = db.Column(db.String(55))
    reason = db.Column(db.String(255))
    status = db.Column(db.String(50), default='Pending')
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    employee = db.relationship('Employee', backref='leaves', lazy=True)

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id'), nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    time = db.Column(db.Time, nullable=False, default=datetime.utcnow().time)

    # Relationship with Employee
    employee = db.relationship('Employee', backref='attendances')

def insert_default_data():
    # Check if the Employee table is empty
    if Employee.query.count() == 0:
        # Create default employee
        default_employee = Employee(
            name="Compact Builders",
            dob="2000-01-01",  # Adjust to your date format
            gender="Male",
            aadhaar="123456789101",
            pan="ABCDE1234F",
            contact="9876543210",
            email="john.doe@example.com",
            address="123 Main St, City, Country",
            position="HR",
            manager="Jane Smith",
            doj="2024-01-15",  # Adjust to your date format
            upi="john.doe@upi",
            bank_account="123456789012",
            data_added_by="Developer"
        )
        db.session.add(default_employee)
        db.session.commit()

        # Create default login
        default_login = Login(
            employee_id=default_employee.id,
            password=generate_password_hash("admin@200"),  # Hash this in production
            data_added_by="Developer"
        )
        db.session.add(default_login)
        db.session.commit()

def init_db():
    with app.app_context():
        db.create_all()
        # insert_default_data()

@login_manager.user_loader
def load_user(user_id):
    return Login.query.get(int(user_id))

# Login route
@app.route('/', methods=['GET','POST'])
def login():
    # Check if the user is already logged in
    if current_user.is_authenticated:
        # Redirect to the base page or dashboard if already logged in
        return redirect(url_for('base'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        try:
            # First, get the employee by email
            employee = Employee.query.filter_by(email=username).first()
        except:
            flash('No Database Found', 'danger')
            return redirect(url_for('login'))

        if employee:
            # Now check if there's a corresponding Login entry
            user = Login.query.filter_by(employee_id=employee.id).first()
            
            if user and check_password_hash(user.password, password):
                login_user(user)
                return redirect(url_for('attendance'))
            else:
                flash('Invalid password. Please try again.', 'danger')
        else:
            flash('Invalid username. Please try again.', 'danger')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/base')
@login_required
def base():
    return render_template('base.html') # Redirect to a landing page/ lead generation

@app.route('/dashboard')
@login_required
def dashboard():
    user = current_user
    current_employee = Employee.query.filter_by(id=user.employee_id).first()
    return render_template('dashboard.html', employee=current_employee, active_page='dashboard')

@app.route('/employee', methods=['GET', 'POST'])
@login_required
def employee():
    # Get the logged-in user's position
    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()

    if request.method == 'POST':

        if employee_position != 'hr':
            logout_user()  # Log the user out
            flash("You don't have permission to perform this action", 'danger')
            return redirect(url_for('login'))
        
        try:
            img_file = request.files['image']
            if img_file and img_file.filename != '':
                filename = secure_filename(img_file.filename)
                unique_filename = f"{request.form['aadhaar']}_{filename}"
                img_filepath = os.path.join(app.config['UPLOAD_FOLDER_img'], unique_filename)
                img_file.save(img_filepath)
            else:
                img_filepath = None  
        except:
            img_filepath = None  

        try:
            aadhaar_file = request.files['aadhaarFile']
            if aadhaar_file and aadhaar_file.filename != '':
                filename = secure_filename(aadhaar_file.filename)
                unique_filename = f"{request.form['aadhaar']}_{filename}"
                aadhaar_filepath = os.path.join(app.config['UPLOAD_FOLDER_aadhaar'], unique_filename)
                aadhaar_file.save(aadhaar_filepath)
            else:
                aadhaar_filepath = None  
        except:
            aadhaar_filepath = None  

        try:
            pan_file = request.files['panFile']
            if pan_file and pan_file.filename != '':
                filename = secure_filename(pan_file.filename)
                unique_filename = f"{request.form['aadhaar']}_{filename}"
                pan_filepath = os.path.join(app.config['UPLOAD_FOLDER_pan'], unique_filename)
                pan_file.save(pan_filepath)
            else:
                pan_filepath = None  
        except:
            pan_filepath = None  

        user = current_user

        new_employee = Employee(
            name=request.form['name'],
            dob=request.form['dob'],
            gender=request.form['gender'],
            aadhaar=request.form['aadhaar'],
            pan=request.form['pan'],
            contact=request.form['contact'],
            email=request.form['email'],
            address=request.form['address'],
            position=request.form['position'],
            manager=request.form['manager'],
            doj=request.form['doj'],
            upi=request.form['upi'],
            bank_account=request.form['bankAccount'],
            image_path=img_filepath.replace('\\', '/'),
            aadhaar_path=aadhaar_filepath.replace('\\', '/'),
            pan_path=pan_filepath.replace('\\', '/'),
            data_added_by=user.employee_id
        )
        
        try:
            db.session.add(new_employee)
            db.session.commit()

            # Create login entry
            new_login = Login(employee_id=new_employee.id, password=generate_password_hash("touch@200"), data_added_by=user.employee_id)
            db.session.add(new_login)
            db.session.commit()

            flash(f"Added New Employee '{request.form['name']}' successfully!", 'success') 
            return redirect(url_for('employee'))
        except:
            db.session.rollback()  # Rollback in case of error
            flash("An error occurred while adding the employee details. Please try again.", 'danger')
            return redirect(url_for('employee'))
    
    # can_modify = employee_position in ['hr', 'admin']
    # if employee_position.lower() == 'hr':
    #     employees_data = Employee.query.filter_by(position='HR').all()
    #     can_modify = True

    employees_data = Employee.query.all()
    return render_template('employee.html', employees=employees_data, role=employee_position, active_page='employee',)

@app.route('/edit_employee', methods=['POST'])
@login_required
def edit_employee():
    if request.method == 'POST':

        user = current_user
        employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()
        if employee_position not in ['hr', 'admin']:
            logout_user()  # Log the user out
            flash("You don't have permission to perform this action", 'danger')
            return redirect(url_for('login'))

        employee_id = request.form['id']
        employee = Employee.query.get(employee_id)

        if employee:
            try:
                img_file = request.files['image']
                if img_file and img_file.filename != '':
                    filename = secure_filename(img_file.filename)
                    unique_filename = f"{request.form['aadhaar']}_{filename}"
                    img_filepath = os.path.join(app.config['UPLOAD_FOLDER_img'], unique_filename)
                    img_file.save(img_filepath)
                else:
                    img_filepath = None  
            except:
                img_filepath = None  

            name = request.form.get('name')
            dob = request.form.get('dob')
            gender = request.form.get('gender')
            aadhaar = request.form.get('aadhaar')
            pan = request.form.get('pan')
            contact = request.form.get('contact')
            email = request.form.get('email')
            address = request.form.get('address')
            position = request.form.get('position')
            manager = request.form.get('manager')
            doj = request.form.get('doj')
            upi = request.form.get('upi')
            bank_account = request.form.get('bankAccount')

            prev_name = employee.name
            
            employee.name = name
            employee.dob = dob
            employee.gender = gender
            employee.aadhaar = aadhaar
            employee.pan = pan
            employee.contact = contact
            employee.email = email
            employee.address = address
            employee.position = position
            employee.manager = manager
            employee.doj = doj
            employee.upi = upi
            employee.bank_account = bank_account
            employee.data_added_by = user.employee_id
            if img_filepath:
                employee.image_path = img_filepath.replace('\\', '/')
            try:
                db.session.commit()
                flash(f'Employee {prev_name} exists! Updating details...', 'primary')
                flash(f'{name} details updated successfully!', 'success')
                return redirect(url_for('employee'))
            except:
                db.session.rollback()  # Rollback in case of error
                flash("An error occurred while editing the employee details. Please try again.", 'danger')
                return redirect(url_for('employee'))
        flash("Employee doesn't exist!!!", 'danger')
        return redirect(url_for('employee'))
    return redirect(url_for('employee'))

@app.route('/delete-employee/<int:employee_id>', methods=['GET', 'Post'])
@login_required
def delete_employee(employee_id):
    
    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()
    if employee_position not in ['hr', 'admin']:
        logout_user()  # Log the user out
        flash("You don't have permission to perform this action", 'danger')
        return redirect(url_for('login'))

    if employee_id==user.employee_id:
        flash(f'You can not delete your own data, please ask your Superior.', 'danger')
        return redirect(url_for('employee'))
    
    employee = Employee.query.get(employee_id)
    if employee:
        # Remove the associated login entry
        if employee.logins:
            db.session.delete(employee.logins[0])  # Assuming one-to-one relationship
        
        # Remove associated payroll records
        payroll_records = Payroll.query.filter_by(employee_id=employee_id).all()
        for payroll in payroll_records:
            db.session.delete(payroll)
        
        # Remove associated leaves records
        leaves_records = Leave.query.filter_by(employee_id=employee_id).all()
        for leave in leaves_records:
            db.session.delete(leave)

        db.session.delete(employee)
        db.session.commit()
        flash(f'Employee {employee.name} (ID: {employee.id}) deleted successfully', 'success')
    else:
        flash(f'Employee not found', 'error')
    return redirect(url_for('employee'))

@app.route('/leaves', methods=['GET', 'POST'])
@login_required
def leaves():
    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()
    if request.method == 'POST':
        try:
            # Validate the form inputs
            employee_id = user.employee_id
            start_date = request.form.get('startDate')
            end_date = request.form.get('endDate')
            reason = request.form.get('reason')
            leave_type = request.form.get('leaveType')

            if not all([start_date, end_date, reason, leave_type]):
                flash('All fields are required!', 'warning')
                return redirect(url_for('leaves'))

            leave = Leave(
                employee_id=employee_id,
                start_date=start_date,
                end_date=end_date,
                reason=reason,
                leave_type=leave_type
            )
            
            db.session.add(leave)
            db.session.commit()

            flash('Leave applied successfully!', 'success')

        except Exception as e:
            db.session.rollback()
            flash(f'Failed to apply leave!', 'danger')
        
        return redirect(url_for('leaves'))

    can_view = employee_position in ['hr', 'admin']
    
    try:
        if employee_position == 'hr':
            # HR can see their own leaves and all non-HR/non-admin leaves
            leave_data = Leave.query.join(Employee).filter(
                (Employee.position != 'hr') & 
                (Employee.position != 'admin') | 
                (Leave.employee_id == user.employee_id)
            ).order_by(
                db.case((Leave.status == 'Pending', 0), else_=1),  # Sort "Pending" status first
                Leave.created_at.desc()  # Then sort by applied date
            ).all()

        elif employee_position == 'admin':
            # Admin sees all leave records
            leave_data = Leave.query.order_by(
                db.case((Leave.status == 'Pending', 0), else_=1),  # Sort "Pending" status first
                Leave.created_at.desc()  # Then sort by applied date
            ).all()

        else:
            # Other employees only see their own leave data
            leave_data = Leave.query.filter_by(
                employee_id=user.employee_id
            ).order_by(
                db.case((Leave.status == 'Pending', 0), else_=1),  # Sort "Pending" status first
                Leave.created_at.desc()  # Then sort by applied date
            ).all()

        current_date = datetime.utcnow().date()
        for leave in leave_data:
            if leave.status == 'Pending':
                if leave.start_date and leave.start_date < current_date:
                    leave.status = 'Rejected'
                    db.session.commit() 

    except:
        leave_data = []
        flash(f'Error fetching leave records', 'danger')

    return render_template('leaves.html', leaves=leave_data, can_modify=can_view, data=[user.employee_id, current_date], active_page='leaves')

@app.route('/leaves/update_status', methods=['POST'])
@login_required
def update_leave_status():
    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()
    if employee_position not in ['hr', 'admin']:
        logout_user()  # Log the user out
        flash("You don't have such rights", 'danger')
        return redirect(url_for('login'))

    data = request.get_json()
    leave_id = data.get('leave_id')
    new_status = data.get('status')

    # Find the leave record in the database using leave_id
    leave = Leave.query.get(leave_id)
    
    if not leave:
        return jsonify({'success': False, 'message': 'Leave record not found'}), 404
    
    try:
        leave.status = new_status
        db.session.commit()
        return jsonify({'success': True}), 200
    
    except Exception as e:
        db.session.rollback()  # Rollback the transaction in case of error
        return jsonify({'success': False, 'message': "Failed to update leave status"}), 500

@app.route('/payroll', methods=['GET', 'POST'])
@login_required
def payroll():
    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()

    if request.method == 'POST':

        if employee_position != 'accountant':
            logout_user()  # Log the user out
            flash("You don't have permission to perform this action", 'danger')
            return redirect(url_for('login'))
        
        try:
            employee_id = request.form['employeeID']

            # Retrieve the employee details from the Employee table
            employee = Employee.query.filter_by(id=employee_id).first()

            if not employee:
                flash(f'Employee (Employee ID: {employee_id}) not found!', 'danger')
                return redirect(url_for('payroll'))

            payment_mode = request.form['paymentMode']
            payment_date = request.form['paymentDate']
            salary_month = request.form['salaryMonth']
            salary_year = request.form['salaryYear']
            amount = float(request.form['amount'])

            # Create a new payroll record
            new_payroll = Payroll(
                employee_id=employee_id,
                payment_mode=payment_mode,
                payment_date=datetime.strptime(payment_date, '%Y-%m-%d'),
                salary_month=salary_month,
                salary_year=salary_year,
                amount=amount
            )

            # Add to the session and commit
            db.session.add(new_payroll)
            db.session.commit()
            flash(f'Payroll record of Employee (ID: {employee_id}) added successfully!', 'success')
            return redirect(url_for('payroll'))
        
        except:
            db.session.rollback()
            flash('Error adding payroll record. Please try again with correct data.', 'danger')
            return redirect(url_for('payroll'))

    # Allow 'admin', and 'accountant' to modify payroll data
    can_modify = employee_position in ['accountant']
    can_view = employee_position in ['admin', 'accountant']
    employees_data = Employee.query.all()

    try:
        # Define month order for sorting
        month_order = {
            'January': 1, 'February': 2, 'March': 3,
            'April': 4, 'May': 5, 'June': 6,
            'July': 7, 'August': 8, 'September': 9,
            'October': 10, 'November': 11, 'December': 12
        }

        # HR, Admin, and Accountant can view all payroll records, while others can only view their own
        if can_view:
            payroll_records = Payroll.query.order_by(
                Payroll.salary_year.desc(),
                case(month_order, value=Payroll.salary_month).desc()
            ).all()
        else:
            # Non-privileged users can only view their own payroll records
            payroll_records = Payroll.query.filter_by(employee_id=user.employee_id).order_by(
                Payroll.salary_year.desc(),
                case(month_order, value=Payroll.salary_month).desc()
            ).all()

        return render_template('payroll.html', payroll_records=payroll_records, can_modify=can_modify, employees_data=employees_data, active_page='payroll')

    except:
        payroll_records = []
        flash(f'Error retrieving payroll data.', 'danger')
        return render_template('payroll.html', payroll_records=payroll_records, can_modify=can_modify, employees_data=employees_data, active_page='payroll')
    
@app.route('/upload_bulk_data', methods=['POST'])
@login_required
def upload_bulk_data():

    user = current_user
    employee_position = Employee.query.filter_by(id=user.employee_id).first().position.lower()
    if employee_position != 'accountant':
        logout_user()  # Log the user out
        flash("You don't have permission to perform this action", 'danger')
        return redirect(url_for('login'))

    if 'file' not in request.files:
        return make_response(jsonify({'success': False, 'error': 'No file part'}), 400)

    file = request.files['file']
    
    if not file or file.filename == '':
        return make_response(jsonify({'success': False, 'error': 'No selected file'}), 400)

    if not file.filename.endswith(('.xlsx', '.xls')):
        return make_response(jsonify({'success': False, 'error': 'Invalid file type. Only Excel files are allowed.'}), 400)
    
    try:
        df = pd.read_excel(file)
    except Exception as e:
        return make_response(jsonify({'success': False, 'error': f'File reading error: {e}'}), 400)

    # Validate required columns
    required_columns = ['Employee ID', 'Payment Mode', 'Payment Date', 'Salary Month', 'Salary Year', 'Amount']
    missing_columns = [col for col in required_columns if col not in df.columns]

    if missing_columns:
        return make_response(jsonify({'success': False, 'error': f'Missing columns: {", ".join(missing_columns)}'}), 400)
    
    valid_payment_modes = {'Cash', 'Bank Transfer', 'UPI'}
    valid_months = {
        'January', 'February', 'March', 'April', 'May', 'June', 
        'July', 'August', 'September', 'October', 'November', 'December'
    }

    try:
        # Transaction block for safe database insert
        with db.session.begin_nested():
            for _, row in df.iterrows():
                # Validate individual row
                if pd.isna(row['Employee ID']) or pd.isna(row['Payment Mode']) or pd.isna(row['Payment Date']):
                    raise ValueError('Missing required fields in data')

                if not isinstance(row['Employee ID'], int):
                    raise ValueError(f'Invalid Employee ID format: {row["Employee ID"]}')
                
                if row['Payment Mode'] not in valid_payment_modes:
                    raise ValueError(f'Invalid Payment Mode: {row["Payment Mode"]}')
                
                try:
                    payment_date = pd.to_datetime(row['Payment Date'])
                except Exception as e:
                    raise ValueError(f'Invalid Payment Date format: {row["Payment Date"]}')
                
                if row['Salary Month'] not in valid_months:
                    raise ValueError(f'Invalid Salary Month: {row["Salary Month"]}')
                
                try:
                    amount = float(row['Amount'])
                    if amount <= 0:
                        raise ValueError(f'Amount must be greater than zero: {row["Amount"]}')
                except ValueError:
                    raise ValueError(f'Invalid Amount format: {row["Amount"]}')
                
                # Check employee existence
                employee = Employee.query.get(row['Employee ID'])
                if not employee:
                    raise ValueError(f'Employee ID does not exist: {row["Employee ID"]}')
                
                # Create Payroll record
                payroll = Payroll(
                    employee_id=row['Employee ID'],
                    payment_mode=row['Payment Mode'],
                    payment_date=payment_date,
                    salary_month=row['Salary Month'],
                    salary_year=row['Salary Year'],
                    amount=amount
                )
                db.session.add(payroll)

            # Commit all records
            db.session.commit()
        
        return make_response(jsonify({'success': True, 'message': "Successfully loaded data"}), 200)

    except IntegrityError:
        db.session.rollback()
        return make_response(jsonify({'success': False, 'error': 'Database error occurred'}), 500)
    except ValueError as e:
        return make_response(jsonify({'success': False, 'error': str(e)}), 400)
    except Exception as e:
        db.session.rollback()
        return make_response(jsonify({'success': False, 'error': f'Something went wrong: {e}'}), 500)

@app.route('/logout')
@login_required
def logout():
    logout_user()  # Log the user out
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


# FR Attendance
# Initialize face cascade
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

@app.route('/attendance')
@login_required
def attendance():
    # Check if attendance has already been marked for today
    user = current_user
    today = datetime.utcnow().date()
    existing_attendance = Attendance.query.filter_by(employee_id=user.employee_id, date=today).first()

    if existing_attendance:
        # If attendance is already marked, you can skip or notify
        flash("Attendance already marked for today.", "info")
        return redirect(url_for('dashboard'))
    
    return render_template('attendance.html')

def generate_frames():
    camera = cv2.VideoCapture(0)  # Explicitly manage camera
    try:
        while True:
            success, frame = camera.read()
            if not success:
                break
            else:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

                for (x, y, w, h) in faces:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

                ret, buffer = cv2.imencode('.jpg', frame)
                frame = buffer.tobytes()

                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    finally:
        camera.release()  # Ensure camera is released when done

@app.route('/video_feed')
@login_required
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/mark_attendance', methods=['POST'])
@login_required
def mark_attendance():
    employee = current_user.employee

    # Capture image from the webcam
    camera = cv2.VideoCapture(0)
    success, frame = camera.read()
    camera.release()

    if not success:
        flash("Failed to capture image.", "danger")
        return redirect(url_for('attendance'))

    # Convert the frame to RGB (DeepFace expects RGB images)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detect faces
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    if len(faces) == 0:
        flash("No face detected.", "danger")
        return redirect(url_for('attendance'))

    # Use the first detected face
    (x, y, w, h) = faces[0]
    detected_face = rgb_frame[y:y+h, x:x+w]

    # Load saved employee image
    saved_image_path = employee.image_path
    if not os.path.exists(saved_image_path):
        flash("Saved image not found.", "danger")
        return redirect(url_for('attendance'))

    try:
        # Verify the captured face with DeepFace using the Facenet model (lighter and faster)
        result = DeepFace.verify(detected_face, saved_image_path, model_name='VGG-Face') # model_name = Facenet, VGG-Face

        if result['verified']:
            # Mark attendance in the database
            mark_attendance_in_db(employee.id)
            flash(f"Attendance marked for {employee.name}!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Face not recognized.", "danger")
            return redirect(url_for('attendance'))

    except Exception as e:
        flash(f"Error in face recognition: {str(e)}", "danger")
        return redirect(url_for('attendance'))

def mark_attendance_in_db(employee_id):
    # Create a new attendance record
    new_attendance = Attendance(employee_id=employee_id, date=datetime.utcnow().date(), time=datetime.utcnow().time())
    db.session.add(new_attendance)
    db.session.commit()

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
