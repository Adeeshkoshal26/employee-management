# Compact-Builders
A web application built with Flask for managing records of customers interested in purchasing properties such as houses and flats.

---



Here's the updated professional manual incorporating the additional constraints and adjustments:

---

# **Excel Data Upload Manual**

## **Introduction**

This manual provides comprehensive instructions for preparing and uploading Excel files for data import. Adherence to the specified formats and constraints ensures smooth data processing and integration.

## **File Requirements**

### **1. File Format**

- **File Type**: Excel (.xlsx or .xls)
- **Allowed MIME Types**:
  - `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` (for .xlsx files)
  - `application/vnd.ms-excel` (for .xls files)

### **2. File Size**

- **Maximum File Size**: 50 MB

## **Excel File Structure**

### **1. Column Names**

The Excel file must contain the following columns. Ensure that the column names match exactly as specified:

- `Employee ID`
- `Payment Mode`
- `Payment Date`
- `Salary Month`
- `Salary Year`
- `Amount`

### **2. Data Types and Constraints**

Each column must adhere to the following data types and constraints:

1. **Employee ID**
   - **Type**: Integer
   - **Format**: Numeric (e.g., `12345`)
   - **Constraint**: Must be a unique identifier for each employee. The ID must correspond to an existing employee in the database.

2. **Payment Mode**
   - **Type**: String
   - **Format**: Alphanumeric (e.g., `Cash`, `Bank Transfer`, `UPI`)
   - **Constraint**: Must be one of the following values: `Cash`, `Bank Transfer`, or `UPI`.

3. **Payment Date**
   - **Type**: Date
   - **Format**: `YYYY-MM-DD` (e.g., `2024-01-15`)
   - **Constraint**: Must be a valid date. Any invalid date format will cause an error.

4. **Salary Month**
   - **Type**: String
   - **Format**: Full month name (e.g., `January`, `February`)
   - **Constraint**: Must be a valid month name from the following list:
     - `January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`.

5. **Salary Year**
   - **Type**: String
   - **Format**: Year in `YYYY` format (e.g., `2024`)
   - **Constraint**: Must be a four-digit year.

6. **Amount**
   - **Type**: Float
   - **Format**: Numeric with up to two decimal places (e.g., `1500.50`)
   - **Constraint**: Represents the salary amount and must be greater than zero.

## **Data Validation Rules**

The following validations are performed on the uploaded Excel data:

1. **Basic Validation**:
   - **Required Columns**: Ensure all required columns (`Employee ID`, `Payment Mode`, `Payment Date`, `Salary Month`, `Salary Year`, `Amount`) are present.
   - **Column Existence**: Verify that there are no missing required columns. If any columns are missing, an error message specifying the missing columns will be returned.
   - **Data Format**: All data entries must match the required formats and types.
   - **Employee Existence**: The `Employee ID` must correspond to an existing employee in the database.

2. **Advanced Validation**:
   - **Payment Mode**: Must be one of `Cash`, `Bank Transfer`, or `UPI`.
   - **Salary Month**: Must be a valid month name from the predefined list.
   - **Amount**: Must be a positive number formatted correctly as a float.
   - **Date Format**: Ensure that the `Payment Date` is a valid date in `YYYY-MM-DD` format.

## **Error Handling**

- **Missing Columns**: Check that all required columns are included in the Excel file.
- **Invalid Data Formats**: Verify that all data entries conform to the required formats and types.
- **Invalid Values**: Ensure values are within acceptable ranges and formats.
- **Employee Validation**: Confirm that the `Employee ID` exists in the database.

## **Upload Process**

1. **Initiate Upload**: Click on the upload button to open the file dialog.
2. **Select File**: Choose the Excel file to upload.
3. **File Validation**: The system will validate the file type, size, and content based on the above constraints.
4. **Progress Indicator**: A progress bar will indicate the upload status.
5. **Completion**: Once the upload is complete, the system will process the file and update the data accordingly.

## **Troubleshooting**

- **File Upload Issues**: Ensure the file type, size, and format meet the requirements.
- **Data Import Errors**: Verify that column names, data types, and value constraints are correctly followed.
- **System Errors**: Review console logs for detailed error messages and adjust the file accordingly.

## **Contact Support**

For further assistance, please contact our support team at [support@example.com](mailto:support@example.com).

---

This updated manual incorporates the additional constraints and file size adjustment, ensuring users are well-informed about the requirements for a successful data upload.
=======
